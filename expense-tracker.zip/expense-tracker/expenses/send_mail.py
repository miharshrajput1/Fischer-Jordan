from django.core.mail import send_mail
from django.conf import settings
from .models import Notification


def notify_user(user, title, message, send_email=True):
    '''
    Function to notify user via email and create a notification in the database
    Create Notification in DB
    '''    

    Notification.objects.create(user=user, title=title, message=message)

    # Send Email
    if send_email:
        send_mail(
            subject=title,
            message=message,
            from_email=settings.DEFAULT_FROM_EMAIL,
            recipient_list=[user.email],
            fail_silently=False
        )
